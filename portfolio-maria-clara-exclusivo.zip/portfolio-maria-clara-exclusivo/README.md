# Portfólio exclusivo — Maria Clara

Este modelo usa uma identidade visual editorial, com tipografia serifada, tons de rosa queimado, vinho e creme, cartões inclinados e projetos em formato de revista.

## Arquivos
- `index.html`: estrutura do site.
- `css/style.css`: estilo, Grid, Flexbox, tema escuro e responsividade.
- `js/script.js`: menu hambúrguer, saudação, tema, ano e validação do formulário.
- `img/`: coloque sua foto como `minha-foto.jpg`.

## Executar
1. Abra a pasta no VS Code.
2. Adicione a foto em `img/minha-foto.jpg`.
3. Abra `index.html` no navegador ou use a extensão Live Server.
4. Teste o menu em tela pequena, alternância de tema, formulário e navegação por teclado.

## Importante
O formulário só valida os dados no navegador. Ele não envia nem guarda mensagens. Revise as descrições dos projetos para que correspondam ao que você realmente implementou.

## Defesa individual
- HTML: estrutura semântica com `header`, `nav`, `main`, `section`, `article`, `form` e `footer`.
- CSS: variáveis, Grid, Flexbox, breakpoints em `@media` e cores dos temas.
- JavaScript: `Date`, `addEventListener`, `classList`, `dataset`, validação e `textContent`.
- Acessibilidade: rótulos de formulário, texto alternativo, `aria-label`, `aria-expanded`, `aria-live`, link para pular conteúdo e foco visível.
